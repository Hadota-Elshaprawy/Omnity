package com.omniaworld.app;

import android.content.*;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        NotificationScheduler.schedule(context);
    }
}
