package com.omniaworld.app;

import android.app.*;
import android.content.*;
import android.os.SystemClock;

public class NotificationScheduler {
    private static final int REQ = 3818;
    public static void schedule(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(context, NotificationReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context, REQ, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long first = SystemClock.elapsedRealtime() + 3L * 60L * 60L * 1000L;
        am.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, first,
                3L * 60L * 60L * 1000L, pi);
    }
}
