package com.omniaworld.app;

import android.app.*;
import android.content.*;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import java.io.*;
import java.util.*;

public class NotificationReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "omnia_3hour";

    public static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "رسائل عالم أمنيتي", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("رسالة رومانسية كل 3 ساعات");
            nm.createNotificationChannel(ch);
        }
    }

    private String nextMessage(Context c) {
        try {
            ArrayList<String> lines = new ArrayList<>();
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getAssets().open("notifications.txt"), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) {
                int p = line.indexOf(". ");
                lines.add(p >= 0 ? line.substring(p + 2) : line);
            }
            br.close();
            if (lines.isEmpty()) return "أنا بحبك يا أمنيتي 💙";
            android.content.SharedPreferences sp = c.getSharedPreferences("omnia_notifications", Context.MODE_PRIVATE);
            int idx = sp.getInt("index", 0);
            String msg = lines.get(idx % lines.size());
            sp.edit().putInt("index", (idx + 1) % lines.size()).apply();
            return msg;
        } catch (Exception e) {
            return "أنا بحبك يا أمنيتي 💙";
        }
    }

    @Override public void onReceive(Context context, Intent intent) {
        createChannel(context);
        String msg = nextMessage(context);
        NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("💙 عالم أمنيتي")
                .setContentText(msg)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(msg))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, 88, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        b.setContentIntent(pi);
        ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%100000), b.build());
    }
}
